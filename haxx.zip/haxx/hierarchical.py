import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
x = [18,22,25,27,42,43]
y = [18,22,25,27,42,43]
data = list(zip(x, y))
x_labels = [str(point) for point in data]
linkage_data = linkage(data, method='complete' , metric='euclidean')
dendrogram(linkage_data, labels =x_labels)
plt.show()