#include <iostream>
#include <cstdlib>
using namespace std;

int main()
    {
    int numbers, k, kvals[25], prevKvals[25], steps = 1, addition[25][100], count = 0,
    groups[25][100] = {0}, min, groupnum, value, sum, ok = 1, nums[100];
    cout << "How many numbers you want to enter: ";
    cin >> numbers;
    cout << "Enter value of k: ";
    cin >> k;
    // Get numbers
    for (int i = 0; i < numbers; i++)
    {
        cout << "Enter Number " << i + 1 << ": ";
        cin >> nums[i];
    }
    
    // Set values of C's
    
    for (int i = 0; i < k; i++)
    {
        kvals[i] = nums[i];
    }
 
    // Show values of user
    cout << "You have entered: ";
    for (int i = 0; i < numbers; i++)
    {
        cout << nums[i] << ", ";
    }
    // While loop for iterations
    while (ok == 1)
    {
        cout << endl
        << "Iteration Number: " << steps;
    // Make calculations
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < numbers; j++)
        {
            addition[i][j] = abs(kvals[i] - nums[j]);
        }
    }
    // Make groups of numbers (C)
    for (int i = 0; i < numbers; i++)
    {
        min = 100000;
        for (int j = 0; j < k; j++)
        {
            if (addition[j][i] < min)
            {
                min = addition[j][i];
                value = nums[i];
                groupnum = j;
            }
        }
    groups[groupnum][i] = value;
    }
 
 // Show results of calculations
    cout << endl
    << "Calculations" << endl;
    for (int i = 0; i < numbers; i++)
    {
        for (int j = 0; j < k; j++)
        {
            cout << addition[j][i] << "\t";
        }
    cout << endl;
    }
 
 // Show groups and get new C's
    cout << endl
    << "Groups" << endl;
    for (int i = 0; i < k; i++)
    {
        sum = 0;
        count = 0;
        cout << "Group " << i + 1 << ": ";
        for (int j = 0; j < numbers; j++)
        {
            if (groups[i][j] != 0)
            {
                cout << groups[i][j] << "\t";
                sum += groups[i][j];
                count++;
            }
        }
    prevKvals[i] = kvals[i];
    kvals[i] = sum / count;
    cout << "\t=\t" << kvals[i] << endl;
 }
 // Make empty array of groups
    for (int i = 0; i < 25; i++)
    {
        for (int j = 0; j < 100; j++)
        {
            groups[i][j] = 0;
        }
    }
 // Check condition of termination
    ok = 0;
    for (int i = 0; i < k; i++)
    {
        if (prevKvals[i] != kvals[i])
        {
            ok = 1;
        }
    }
    steps++;
 } 
 // End while loop
 // Wait for user input before exiting
 
 cout << "Press any key to continue . . . ";
 cin.ignore();
 cin.get();
 return 0;
}